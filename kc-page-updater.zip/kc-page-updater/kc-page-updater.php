<?php
/**
 * Plugin Name: KC Page Updater
 * Description: One-time page content update. Deactivate after use.
 * Version: 1.0
 */

register_activation_hook(__FILE__, function() {
    $content = '<style>
#masthead .header,header#masthead .header,.elementor-4803 .header{background-color:#402417 !important}
.kc-home *,.kc-home *::before,.kc-home *::after{margin:0;padding:0;box-sizing:border-box}
.kc-home{--brand:#402417;--gold:#c9a96e;font-family:\'Cormorant Garamond\',Georgia,serif;color:#402417}
.kc-hero-zone{position:relative;height:250vh}
.kc-hero-pin{position:sticky;top:0;height:100vh;overflow:hidden;background:linear-gradient(160deg,#f5efe6 0%,#ede4d6 100%)}
.kc-content-fade{opacity:0;transform:translateY(40px);transition:opacity 0.8s,transform 0.8s}
.kc-content-fade.kc-vis{opacity:1;transform:translateY(0)}
.kc-tagline{padding:100px 20px 80px;background:#fff;text-align:center}
.kc-tagline h2{font-size:clamp(26px,4.5vw,42px);font-weight:300;color:#402417;line-height:1.3;margin-bottom:20px}
.kc-tagline p{font-size:16px;color:#6b5a4e;max-width:540px;margin:0 auto 40px;font-family:\'Open Sans\',sans-serif;font-weight:300;line-height:1.8}
.kc-btn-row{display:flex;gap:20px;justify-content:center;flex-wrap:wrap}
.kc-btn{display:inline-block;padding:16px 44px;font-size:12px;letter-spacing:3px;text-transform:uppercase;text-decoration:none;transition:all 0.35s;font-family:\'Open Sans\',sans-serif}
.kc-btn-gold{background:#c9a96e;color:#402417;border:2px solid #c9a96e}
.kc-btn-gold:hover{background:transparent;color:#c9a96e}
.kc-btn-dark{background:transparent;color:#402417;border:2px solid #402417}
.kc-btn-dark:hover{border-color:#c9a96e;color:#c9a96e}
.kc-btn-outline{background:transparent;color:#fff;border:2px solid rgba(255,255,255,0.4)}
.kc-btn-outline:hover{border-color:#c9a96e;color:#c9a96e}
.kc-section-tag{font-size:12px;letter-spacing:6px;text-transform:uppercase;color:#c9a96e;margin-bottom:16px;font-family:\'Open Sans\',sans-serif}
.kc-section-h2{font-size:clamp(30px,5vw,48px);font-weight:300;color:#402417;margin-bottom:60px;line-height:1.2}
.kc-collections{padding:100px 20px;background:#faf7f3;text-align:center}
.kc-cat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:24px;max-width:1200px;margin:0 auto}
.kc-cat-card{position:relative;height:400px;border-radius:4px;overflow:hidden;background:#402417}
.kc-cat-card::before{content:\'\';position:absolute;inset:0;background:linear-gradient(to top,rgba(64,36,23,0.95) 0%,rgba(64,36,23,0.15) 60%,transparent 100%);z-index:1}
.kc-cat-link{position:absolute;inset:0;z-index:2;display:flex;flex-direction:column;justify-content:flex-end;padding:32px;text-decoration:none}
.kc-cat-link h3{color:#fff;font-size:26px;font-weight:400;margin-bottom:6px}
.kc-cat-link p{color:#c9a96e;font-size:12px;letter-spacing:3px;text-transform:uppercase;font-family:\'Open Sans\',sans-serif}
.kc-features{padding:100px 20px;background:#fff;text-align:center}
.kc-feat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:60px;max-width:960px;margin:0 auto}
.kc-feat-item{padding:20px}
.kc-feat-icon{width:48px;height:48px;margin:0 auto 20px;stroke:#c9a96e;fill:none;stroke-width:1.2}
.kc-feat-item h3{font-size:24px;font-weight:400;margin-bottom:12px}
.kc-feat-item p{font-size:15px;line-height:1.8;color:#6b5a4e;font-family:\'Open Sans\',sans-serif;font-weight:300}
.kc-cta{padding:120px 20px;background:#402417;text-align:center}
.kc-cta h2{font-size:clamp(28px,5vw,46px);color:#fff;font-weight:300;margin-bottom:16px}
.kc-cta p{color:rgba(255,255,255,0.65);font-size:16px;max-width:480px;margin:0 auto 44px;font-family:\'Open Sans\',sans-serif;font-weight:300;line-height:1.8}
@media(max-width:768px){.kc-collections,.kc-features,.kc-cta,.kc-tagline{padding:60px 16px}.kc-cat-card{height:300px}}
</style>
<div class="kc-home"><section class="kc-hero-zone"><div class="kc-hero-pin" id="kc-hero-pin"></div></section><section class="kc-tagline kc-content-fade"><h2>Where Tradition Meets Elegance</h2><p>Premium bespoke tailoring crafted with African heritage and modern sophistication. Every stitch tells a story of excellence.</p><div class="kc-btn-row"><a href="/shop-ready-made/" class="kc-btn kc-btn-gold">Shop Collection</a> <a href="/consultation/" class="kc-btn kc-btn-dark">Book Consultation</a></div></section><section class="kc-collections kc-content-fade"><div class="kc-section-tag">Our Collections</div><h2 class="kc-section-h2">Explore Our Craft</h2><div class="kc-cat-grid"><div class="kc-cat-card" style="background:linear-gradient(135deg,#5a3828,#3a2010);"><a href="/product-category/men/suits/" class="kc-cat-link"><h3>Suits</h3><p>Tailored to perfection</p></a></div><div class="kc-cat-card" style="background:linear-gradient(135deg,#6b5a4e,#402417);"><a href="/product-category/men/agbada/" class="kc-cat-link"><h3>Agbada</h3><p>Royal African elegance</p></a></div><div class="kc-cat-card" style="background:linear-gradient(135deg,#8b7355,#402417);"><a href="/product-category/men/kaftan/" class="kc-cat-link"><h3>Kaftan</h3><p>Timeless sophistication</p></a></div><div class="kc-cat-card" style="background:linear-gradient(135deg,#4a3525,#2a1508);"><a href="/product-category/men/dashiki/" class="kc-cat-link"><h3>Dashiki</h3><p>Bold cultural style</p></a></div></div></section><section class="kc-features kc-content-fade"><div class="kc-section-tag">Why Kevin Cho</div><h2 class="kc-section-h2">The Art of Bespoke</h2><div class="kc-feat-grid"><div class="kc-feat-item"><svg class="kc-feat-icon" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><h3>Handcrafted</h3><p>Every garment is meticulously crafted by hand with attention to the finest details.</p></div><div class="kc-feat-item"><svg class="kc-feat-icon" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg><h3>Premium Fabrics</h3><p>We source only the finest fabrics from across Africa and around the world.</p></div><div class="kc-feat-item"><svg class="kc-feat-icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg><h3>Worldwide Delivery</h3><p>From Cameroon to the world — we deliver our craftsmanship to your doorstep.</p></div></div></section><section class="kc-cta kc-content-fade"><h2>Your Perfect Fit Awaits</h2><p>Book a consultation and let us create something extraordinary, tailored exclusively for you.</p><div class="kc-btn-row"><a href="/consultation/" class="kc-btn kc-btn-gold">Book a Consultation</a> <a href="/custom-wear/" class="kc-btn kc-btn-outline">Custom Wear</a></div></section></div>
<script>!function(){function kc(){if(document.getElementById(\'kc-anim-img\'))return;var h=document.querySelector(\'#masthead .header\')||document.querySelector(\'.header\');if(!h)return;var wl=\'https://kevincho.com/wp-content/uploads/2025/05/CEVIN-LOGO-WHITE.png\';h.querySelectorAll(\'.logo img\').forEach(function(im){im.src=wl;if(im.dataset&&im.dataset.src)im.dataset.src=wl;im.removeAttribute(\'srcset\');im.removeAttribute(\'data-srcset\');im.style.display=\'block\';im.style.visibility=\'visible\';im.style.position=\'static\';im.style.clip=\'auto\';im.style.maxWidth=\'180px\';im.style.height=\'auto\';});h.querySelectorAll(\'.logo noscript\').forEach(function(n){n.style.display=\'none\';});var hLogo=h.querySelector(\'.logo\');var hContact=h.querySelector(\'.contact-us\');var vh=window.innerHeight,vw=window.innerWidth;var heroZone=document.querySelector(\'.kc-hero-zone\');if(!heroZone)return;var overlay=document.createElement(\'img\');overlay.id=\'kc-anim-img\';overlay.src=wl;overlay.alt=\'Kevin Cho\';overlay.style.cssText=\'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) scale(1);z-index:100000;pointer-events:none;opacity:0;will-change:transform;width:160px;height:auto;transform-origin:center center;\';document.body.appendChild(overlay);var miniHdr=document.createElement(\'div\');miniHdr.id=\'kc-mini-hdr\';miniHdr.style.cssText=\'position:fixed;top:0;left:0;right:0;height:50px;background:#402417;z-index:99990;display:flex;align-items:center;justify-content:center;transform:translateY(-100%);transition:transform 0.4s cubic-bezier(0.4,0,0.2,1);\';miniHdr.innerHTML=\'<img src="\'+wl+\'" style="height:24px;width:auto;" alt="Kevin Cho">\';document.body.appendChild(miniHdr);var hdrH=h.offsetHeight||55;var startY=hdrH/2;var totalScroll=vh*1.8;var initW=160;var peakScale=(vw*1.1)/initW;var ticking=false;function ease(t){return t<0.5?2*t*t:-1+(4-2*t)*t}function lerp(a,b,t){return a+(b-a)*t}function upd(){ticking=false;var sY=window.pageYOffset||0;var p=Math.min(Math.max(sY/totalScroll,0),1);if(p<0.02){overlay.style.opacity=\'0\';overlay.style.transform=\'translate(-50%,-50%) scale(1)\';overlay.style.top=\'50%\';if(hLogo)hLogo.style.opacity=\'\';if(hContact)hContact.style.opacity=\'\';if(h)h.style.cssText=\'\';miniHdr.style.transform=\'translateY(-100%)\';}else if(p<0.50){var t=ease((p-0.02)/0.48);var sc=lerp(1,peakScale,t);var yPos=lerp(startY,vh*0.45,t);overlay.style.top=yPos+\'px\';overlay.style.transform=\'translate(-50%,-50%) scale(\'+sc+\')\';var op=Math.min(t*3,1);if(t>0.4)op=lerp(1,0.15,(t-0.4)/0.6);overlay.style.opacity=op;if(hLogo)hLogo.style.opacity=Math.max(1-t*5,0);if(hContact)hContact.style.opacity=Math.max(1-t*4,0);if(h){var ba=Math.max(1-t*3,0);h.style.backgroundColor=\'rgba(64,36,23,\'+ba+\')\';}miniHdr.style.transform=\'translateY(-100%)\';}else if(p<0.70){overlay.style.top=(vh*0.45)+\'px\';overlay.style.transform=\'translate(-50%,-50%) scale(\'+peakScale+\')\';overlay.style.opacity=\'0.12\';if(hLogo)hLogo.style.opacity=\'0\';if(hContact)hContact.style.opacity=\'0\';if(h)h.style.backgroundColor=\'rgba(64,36,23,0)\';miniHdr.style.transform=\'translateY(-100%)\';}else if(p<0.92){var t2=(p-0.70)/0.22;overlay.style.opacity=lerp(0.12,0,t2);if(hLogo)hLogo.style.opacity=\'0\';if(hContact)hContact.style.opacity=\'0\';if(h)h.style.backgroundColor=\'rgba(64,36,23,0)\';miniHdr.style.transform=\'translateY(-100%)\';}else{overlay.style.opacity=\'0\';if(hLogo)hLogo.style.opacity=\'0\';if(hContact)hContact.style.opacity=\'0\';if(h)h.style.backgroundColor=\'rgba(64,36,23,0)\';miniHdr.style.transform=\'translateY(0)\';}}window.addEventListener(\'scroll\',function(){if(!ticking){requestAnimationFrame(upd);ticking=true;}});window.addEventListener(\'resize\',function(){vh=window.innerHeight;vw=window.innerWidth;peakScale=(vw*1.1)/initW;hdrH=h.offsetHeight||55;startY=hdrH/2;totalScroll=vh*1.8;upd();});upd();var fades=document.querySelectorAll(\'.kc-content-fade\');if(\'IntersectionObserver\' in window){var obs=new IntersectionObserver(function(ents){ents.forEach(function(e){if(e.isIntersecting){e.target.classList.add(\'kc-vis\');obs.unobserve(e.target);}});},{threshold:0.12});fades.forEach(function(el){obs.observe(el);});}else{fades.forEach(function(el){el.classList.add(\'kc-vis\');});}}if(document.readyState===\'loading\'){document.addEventListener(\'DOMContentLoaded\',function(){setTimeout(kc,200);});}else{setTimeout(kc,200);}window.addEventListener(\'load\',function(){setTimeout(kc,500);});}();</script>';
    
    wp_update_post(array(
        'ID' => 5660,
        'post_content' => $content,
    ));
    
    set_transient('kc_page_updated', true, 60);
});

add_action('admin_notices', function() {
    if (get_transient('kc_page_updated')) {
        delete_transient('kc_page_updated');
        echo '<div class="notice notice-success"><p><strong>Homepage updated successfully!</strong> You can now deactivate and delete this plugin.</p></div>';
    }
});
